<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div> Marcação de Consulta</div>

        Nome: <?php echo $_POST["nome"];
        
        ?><br>
        
      
        CPF: <?php echo $_POST["cpf"];
        
        ?><br>
        
        Especialidade: <?php echo $_POST ["especialidade"];
        
        
        ?><br>
        
        medico: <?php echo $_POST["medico"];
        
        ?>
        
       
    </body>
</html>
